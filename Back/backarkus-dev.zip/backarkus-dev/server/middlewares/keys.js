module.exports = {
  secretOrKey: "secret"
};
